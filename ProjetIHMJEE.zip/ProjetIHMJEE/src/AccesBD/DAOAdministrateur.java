package AccesBD;

public class DAOAdministrateur {

}
