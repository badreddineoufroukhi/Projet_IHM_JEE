package AccesBD;

public class DAOAppartenanceFilElem{

}
