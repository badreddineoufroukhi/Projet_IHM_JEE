package Metier;

public class Possede {
      private int codeElem;
      private int codeMod;
	public Possede() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Possede(int codeElem, int codeMod) {
		super();
		this.codeElem = codeElem;
		this.codeMod = codeMod;
	}
	public int getCodeElem() {
		return codeElem;
	}
	public void setCodeElem(int codeElem) {
		this.codeElem = codeElem;
	}
	public int getCodeMod() {
		return codeMod;
	}
	public void setCodeMod(int codeMod) {
		this.codeMod = codeMod;
	}
      
}
